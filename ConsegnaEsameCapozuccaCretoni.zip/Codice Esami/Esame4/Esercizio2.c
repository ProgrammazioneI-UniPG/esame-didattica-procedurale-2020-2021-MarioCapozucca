//Scrivere un programma che crei casualmente un array di 20 interi e lo stampi a video

# include <stdio.h>
# include <stdlib.h> /* per usare rand () e srand () */
# include <time.h> /* per usare time () */
# define SIZE 20

int main (){

int a[SIZE];
int i;
printf ("Il massimo valore casuale generabile e': %d \n" , INT_MAX );
    for (i =0; i < SIZE ; i ++){
        a[i] = rand();
        printf ( "a[%d] = %d \n" ,i ,a[i]);
      }
  }
