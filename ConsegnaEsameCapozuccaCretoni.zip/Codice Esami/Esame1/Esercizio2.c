/*L’utente inserisce una temperatura in Celsius e il calcolatore
la converte in Fahrenheit ed in Kelvin.
Se la temperaura inserita è minore dello zero assoluto(-273.15),
il calcolatore segnala un errore.
Ricordiamo che:
Fahrenheit = (9/5) · Celsius + 32
Kelvin = Celsius + 273,15
Soluzione*/

#include <stdio.h>

int main(){
float celsius, fahrenheit, kelvin, zeroAssolutoCelsius = -273.15;
printf ("Inserire temperatura in Celsius:  ");
scanf ("%f", &celsius);
if (celsius >= zeroAssolutoCelsius){
    fahrenheit = (9.0 / 5.0) * celsius + 32;
    kelvin = celsius - zeroAssolutoCelsius;
    printf ("Fahrenheit: %.2f, Kelvin: %.2f \n", fahrenheit,kelvin);
  } else{
    printf ("Errore!\n");
  }
  return 0;
}
