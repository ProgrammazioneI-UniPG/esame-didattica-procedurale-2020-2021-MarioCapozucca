/*Dire cosa stampa il seguente programma*/
#include <stdio.h>


int main() {
        int i, j, LENGTH=6;

for (i = 0; i < LENGTH; i++){
	for (j = LENGTH - 1; j >= 0; j--){

         if (j <= i)
           printf("*");
         else
           printf(" ");
         }
		   printf("\n");
        }
for (i = 0; i < LENGTH; i++) {
	for (j = LENGTH - 1; j >= 0; j--) {
         if (j >= i)
           printf("*");
         else
           printf(" ");
          }
          printf("\n");
        }
        return 0;
}
