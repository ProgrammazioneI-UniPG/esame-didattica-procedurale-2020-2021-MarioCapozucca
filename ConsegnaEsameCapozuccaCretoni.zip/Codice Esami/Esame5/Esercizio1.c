/*
dire cosa stampa il seguente codice e se ci sono errori:
Il seguente programma inizializza un array a di 10 elementi
con i numeri da 1 a 10 e poi copia il contenuto di a nell’array b che ha la
stessa dimensione
*/
#include <stdio.h>

int main(){
 int a[10], b[10];
 int i;
 
 for(i=0;i<10;i++){
     a[i]= i;
 }
 for(i=0;i<=10;i++){
     b[i] = a[i];
     printf("%d",b[i]);
 }
 return 0;
}

