/*
Scrivere un programma in C dove viene letta una stringa da tastiera,
se ne stampi le lettere e i valori di ogni carattere in CHAR.
*/

#include <stdio.h>

void main(){
 char stringa[10];
 printf ("Inserire una parola: \n");
 scanf("%s", stringa);
 for(int i = 0; i<50;i++){
    if((int)stringa[i] < 1) return 0;
    printf ("La %da lettera e': %c, in ASCII e': %d \n", i+1, stringa[i], stringa[i]);
 }
}
