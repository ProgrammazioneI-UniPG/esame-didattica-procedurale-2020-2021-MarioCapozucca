/*
Si scriva un programma C che legga da tastiera 5 numeri e stampi a video il maggiore tra essi, la
loro media e la radice quadrata della somma.
Si noti che per effettuare la radice quadrata esiste la funzione double sqrt (double)definita
nel file di header: <math.h>
Soluzione: */
#include <stdio.h>
#include <math.h>
void main(){

 int i, a, max=0, somma;
 float r;
 for (i=0; i<5; i++) {
 printf ("Inserisci un numero: ");
    scanf("%d",&a);
    if (max < a){
      max = a;
    }
    somma += a;
  }
 r = somma / 5;
 printf ("Il valore massimo inserito e': %d\n", max);
 printf ("La radice quadrata della somma e': %.3f\n", sqrt(somma));
 printf ("La media e': %.3f\n", r);
}
