//Scrivere cosa fa il seguente programma

#include <stdio.h>
#include <stdlib.h>

int main(){
  int n[6],i;
  int sommapari=0, sommadispari=0;
  for(i=0;i<6;i++)
  {
    printf("Inserisci il %d numero: \n", i+1);
    scanf("%d", &n[i]);
    if(n[i]%2==0)
      sommapari+=n[i];
    else
      sommadispari+=n[i];
  }
  printf("Somma numeri pari= %d \n", sommapari);
  printf("Somma numeri dispari= %d \n", sommadispari);
}
