/*
Siano p e q due puntatori a variabili intere var1 e var2.
Si scriva un programma che svolga i seguenti punti,
per ognuno dei quali viene data una funzione apposita:

• memorizza nelle due variabili intere due valori inseriti
  dall'utente
• stampa il contenuto delle variabili intere ed i loro indirizzi di
  memoria
*/

#include<stdio.h>
#include<stdlib.h>

void memorizza(int *p, int *q){
printf ("\n Inserire due interi separati da uno spazio..");
scanf ("%d %d", p, q);
}
void stampa (int *p, int *q){
printf ("\n indirizzo: %p, contenuto: %d",p,*p);
printf ("\n indirizzo: %p, contenuto: %d",q,*q);
}

int main (){
//dichiarazione
int var1, var2;
int *p, *q;
//link
p = &var1;
q = &var2;
//funzioni:
memorizza (p,q);
stampa (p,q);
return 0;
}
