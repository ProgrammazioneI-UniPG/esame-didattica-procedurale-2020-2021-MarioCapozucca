/*Si scriva un programma in linguaggio C che acquisisca da tastiera una parola (cioè una stringa di
caratteri priva di separatori) e la stampi a video se e solo se tale parola è palindroma, ossia
leggibile nello stesso modo da destra a sinistra e viceversa (es. OSSESSO).
Per determinare la lunghezza della parola si può utilizzare la funzione strlen(s) contenuta nel
file header <string.h>.*/

#include <stdio.h>
#include <string.h>
void main(){

  char s[100];
  int i, flag;
  i = 0;
  printf("Inserire la parola:");
  scanf ("%s", s);

 while ( i < (strlen(s)/2) ){
   if (s[i] != s[strlen(s)-i-1]){
     printf ("La parola non e' palindroma.\n");
     return;
      }
   i++;
  }
  printf ("La parola e' palindroma.\n");
  return;
}
