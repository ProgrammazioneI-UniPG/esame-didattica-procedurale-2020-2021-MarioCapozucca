#include <stdio.h>

int moduli(int a, int b, int c){
    int ris1, ris2, ris3;
    ris1 = a % 2;
    ris2 = b % 3;
    ris3 = c % 4;
}

int main() {
        int a= 100, b= 50, c= -30;
        moduli(a,b,c);
        printf("i Risultati sono: %d, %d, %d ", ris1, ris2,ris3);
        return 0;
}