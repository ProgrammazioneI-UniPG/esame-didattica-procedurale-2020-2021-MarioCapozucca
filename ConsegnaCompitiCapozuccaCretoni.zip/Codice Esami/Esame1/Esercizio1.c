/*Elencare tutte le conversioni di tipo presenti; dire il valore finale di c.*/

#include <stdio.h>

    double circ(float a){
        return (a*a);
    }
int main(void){
    unsigned int a=1LL;
    float b= circ(2.0);
    int c=5.9;
    unsigned short d=1000;
    d=-5;
    printf("%d",c);
}

/*Commenti:
1LL da long long a unsigned int
2.0 da double a float (parametro float)
a*a da float a double
risultato circ da double a float
3.9 da double a int
1000 da int ad unsigned short
-4 da int ad unsigned short
stampa c=5
*/
