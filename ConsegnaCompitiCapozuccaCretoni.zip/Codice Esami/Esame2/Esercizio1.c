// conversione tipo nelle espressioni
// dire risultato (attenzione alla virgola) ed il tipo risultante
// Conversione implicita ed esplicita indicare il tipo delle espressioni

#include <stdio.h>
#include <stdlib.h>
int main(){

  int val1 = 5;
  int val2 = 9;
  float ris;

  ris = val1 / val2;    /* divisione fra interi, poi conversione in float */
  printf("Risultato %d/%d = %6.4f\n", val1, val2, ris); /* stampa 0.0000 */

  ris = val1 / (float)val2;     /* operazione di cast su un operando: divisione fra float */
  printf("Risultato %d/%d = %6.4f\n", val1, val2, ris); /* stampa 0.5556 */

  ris = (float) val1 / val2;
  printf("Risultato %d/%d = %6.4f\n", val1, val2, ris); /* stampa 0.5556 */

  ris = (int) ((float)val1 / val2);
  printf("Risultato %d/%d = %6.4f\n", val1, val2, ris); /* stampa 0.0000 */

  ris = (float) (val1 / val2);
  printf("Risultato %d/%d = %6.4f\n", val1, val2, ris); /* stampa 0.0000 */

  return 0;
}