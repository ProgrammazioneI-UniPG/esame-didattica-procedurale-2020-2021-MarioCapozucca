/* Cosa stampa il seguente codice?
Errore a tempo di computazione, la variabile x ha una visibilità (scope)
limitata al blocco dove è definita "X non definita"
*/

int main(){
  {
    int x=0x12;
  }
  {
    printf("%d",x);
  }
    return 0;
}