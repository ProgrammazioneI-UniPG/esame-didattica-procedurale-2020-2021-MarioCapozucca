//Scrivere un programma che crei casualmente(min 1 e max 100) un array di 10 interi e lo stampi a video
//lo modifichi azzerando tutti gli elementi in posizione di indice pari e quindi stampi l’array modificato.

//Che cosa fa quesro programma?
# include <stdio.h>
# include <stdlib.h> /* per usare rand () e srand () */
# define SIZE 10
int main ()
{
int a[SIZE];
int i;
/* stampa il massimo numero generabile da rand () */
/* printf ("% d\n" , RAND_MAX ); */
for (i =0; i < SIZE ; i ++)
{
a[i ] = 1+rand()%100; /* funzione per creare numeri casuali tra 1 e 100*/
printf ( "a [% d ] = %d \n" ,i ,a[i ]);
}
for (i =0; i < SIZE ; i= i +2)
a[i ] = 0;
for (i =0; i < SIZE ; i ++)
printf ( "a [% d ] = %d \n" ,i ,a[i ]);
}
