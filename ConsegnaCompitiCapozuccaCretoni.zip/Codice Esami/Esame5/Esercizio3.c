/*
Scrivere un programma che crei casualmente un array di 23 interi, lo
stampi a video, lo modifichi azzerando tutti gli elementi in posizione di
indice pari e quindi stampi l’array modificato.
--Usare la funzione rand() della libreria standard (includendo
stdlib.h) che genera interi casuali
Soluzione:
*/
# include <stdio.h>
# include <stdlib.h> /* per usare rand () e srand () */
# include <time.h> /* per usare time () */
# define SIZE 23
int main (){
int a[SIZE];
int i;
// stampa il massimo numero generabile da rand ()
//printf ("% d\n" , RAND_MAX );
// inizializza il generatore di numeri casuali usando l’orologio di sistema
srand ( time (0));
for (i =0; i < SIZE ; i ++){
	a[i ] = rand ();
	printf ( "a [% d ] = %d \n" ,i ,a[i ]);
	}
for (i =0; i < SIZE ; i= i +2)
	a[i] = 0;
}
